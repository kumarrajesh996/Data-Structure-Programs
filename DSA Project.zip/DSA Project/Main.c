#include"prototypes.h"
int main()
{
   front_page();
   return 0;
}
